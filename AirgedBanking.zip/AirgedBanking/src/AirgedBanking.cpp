#include <iostream>
#include <stdexcept>

class Investment {

//declare private variables
private:
    double starting_Amount;
    double monthly_Deposit;
    double annualIntRate;
    int amountYears;


    //functions with if statement
public:
    Investment(double t_initialAmount, double t_monthlyDeposit, double t_annualInterestRate, int t_years)
        : starting_Amount(t_initialAmount), monthly_Deposit(t_monthlyDeposit),
          annualIntRate(t_annualInterestRate), amountYears(t_years) {
        if (t_initialAmount < 0 || t_monthlyDeposit < 0 || t_annualInterestRate < 0 || t_years < 0) {
            throw std::invalid_argument("All parameters must be non-negative.");
        }
    }


    //show report to the user
    void displayReports() const {
        double totalAmt = starting_Amount;
        for (int i = 0; i < amountYears * 12; ++i) {
            totalAmt += monthly_Deposit;
            totalAmt *= (1 + annualIntRate / 12 / 100);
        }
        std::cout << " Your total amount after " << amountYears << " years: " << totalAmt << std::endl;
        std::cout << " Your total interest earned: " << calculateTotalInterest() << std::endl;
    }

    double calculateTotalInterest() const {
        double totalAmount = starting_Amount;
        for (int i = 0; i < amountYears * 12; ++i) {
            totalAmount += monthly_Deposit;
            totalAmount *= (1 + annualIntRate / 12 / 100);
        }
        return totalAmount - (starting_Amount + monthly_Deposit * amountYears * 12);
    }
};

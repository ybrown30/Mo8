#include <iostream>
#include <stdexcept>


//declaring blue print functions
class Investment {
private:
    double monthAmt;
    double depositMonth;
    double annualInterestRate;
    int years;

public:
    Investment(double t_initialAmount, double t_monthlyDeposit, double t_annualInterestRate, int t_years)
        : monthAmt(t_initialAmount), depositMonth(t_monthlyDeposit),
          annualInterestRate(t_annualInterestRate), years(t_years) {
        if (t_initialAmount < 0 || t_monthlyDeposit < 0 || t_annualInterestRate < 0 || t_years < 0) {
            throw std::invalid_argument("please note all inputs should be non-negative.");
        }
    }

    void displayReports() const {
        double totalAmount = monthAmt;
        for (int i = 0; i < years * 12; ++i) {
            totalAmount += depositMonth;
            totalAmount *= (1 + annualInterestRate / 12 / 100);
        }
        std::cout << "Your Total amount after " << years << " years: " << totalAmount << std::endl;
        std::cout << "Your Total interest earned: " << calculateTotalInterest() << std::endl;
    }


    //calculate interest
    double calculateTotalInterest() const {
        double totalAmount = monthAmt;
        for (int i = 0; i < years * 12; ++i) {
            totalAmount += depositMonth;
            totalAmount *= (1 + annualInterestRate / 12 / 100);
        }
        return totalAmount - (monthAmt + depositMonth * years * 12);
    }
};



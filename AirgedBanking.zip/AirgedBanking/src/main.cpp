#include <iostream>
#include "investment.h"


//start program
int main() {
    double initialAmount, userDeposit, annualInterestRate;
    int years;

    std::cout << "Enter your initial investment amount: ";
    std::cin >> initialAmount;
    std::cout << "Enter your monthly deposit: ";
    std::cin >> userDeposit;
    std::cout << "Enter your annual interest rate (in %): ";
    std::cin >> annualInterestRate;
    std::cout << "Enter your number of years to invest ";
    std::cin >> years;

    std::cout << "Press any key to continue...\n";
    std::cin.ignore();
    std::cin.get();


  //try and catch block with method
    try {
        Investment investment(initialAmount, userDeposit, annualInterestRate, years);
        investment.displayReports();
    } catch (const std::invalid_argument& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
